Hello,

The main executable is "ADC Archiver 1.2.0.bin"

1. chmod +x ADC Archiver 1.2.0.bin

2. ./ADC Archiver 1.2.0.bin

All libraries (.so's) are absolutely required, please run the executable from this folder!


Thank you, Mealman1551
